<?php
    //set off all error for security purposes
	//error_reporting(E_ALL);
	

	//define some contstant


define( "DB_HOST", "localhost" );
define( "DB_DSN", "mysql:host=localhost;dbname=selcom_transset" );
define( "DB_USER", "salma" );
define( "DB_PASS", "@selcom09" );
define( "CLS_PATH", "class" );
define( "DB_NAME", "selcom_transset" );
define( "APP_NAME", "Selcom Transsnet API" );